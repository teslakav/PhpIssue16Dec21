<html lang="en">
	<head>
		<title>Research</title>
	</head>
<body> 

<?php
	
	include_once('includes/dbh-inc.php');
	
	$conn = MySQLi_connect($dbServername, $dbUsername, $dbPassword, $dbName);
	
	$sql = 'SELECT * FROM journals2021;';
	$result = mysqli_query($conn, $sql);
	$resultCheck = mysqli_num_rows($result);

	if ($resultCheck > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			echo $row['journal'] . '<br>';
		}
	}
?>
	
<br><br>

<form action="includes/journaladd-inc.php" method="post">
    <input type="text" name="formjournal">
	<br>
    <input type="text" name="formcountry">
	<br>
    <input type="text" name="formpublisher">
	<br>
    <input type="text" name="formfrequency">
	<br>
    <input type="text" name="formkeywords">
	<br>
    <input type="text" name="formdescription">
	<br>
    <input type="text" name="formwebsite">
	<br>
	<button type="submit" name="submit">Add Journal</button>
</form>

</body>
</html>