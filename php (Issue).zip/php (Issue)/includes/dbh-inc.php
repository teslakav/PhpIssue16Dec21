<?php
	
	$dbServername = "mysql.parasocial.work";
	$dbUsername = "parasocialwork";
	$dbPassword = "XXXXXXX";
	$dbName = "psw_journals";

	$conn = MySQLi_connect($dbServername, $dbUsername, $dbPassword, $dbName);
	
?>