<?php
	
	include_once('dbh-inc.php');

	$formjournal = strip_tags(trim($_POST['formjournal']));
	$formcountry = strip_tags(trim($_POST['formcountry']));
	$formpublisher = strip_tags(trim($_POST['formpublisher']));
	$formfrequency = strip_tags(trim($_POST['formfrequency']));
	$formkeywords = strip_tags(trim($_POST['formkeywords']));
	$formdescription = strip_tags(trim($_POST['formdescription']));
	$formwebsite = strip_tags(trim($_POST['formwebsite']));

	$sql = "INSERT INTO journals2021 (journal, country, publisher, frequency, keywords, description, website) VALUES ('$formjournal', $formcountry', '$formpublisher', '$formfrequency', '$formkeywords', '$formdescription', '$formwebsite');";

	MySQLi_query($conn, $sql);
	
	if ( !$conn ) {
		die( 'Did not connect: ' . mysqli_connect_error() ); 
	}

	header("Location: ../researchdb.php?journaladd=success");